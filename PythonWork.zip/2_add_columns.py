import pandas as pd

import re

from datetime import datetime

positions_list = [1,2,3,4,5,6,7,8,9,"D"]

pattern = r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}\s+\d{4}\b'

def greater_than_10(row):
    value = row['Pos']
    try:
        value_split = value.split(sep="/")[0]
        if(value_split == ""):
            return False
        else:
            return True
    except Exception as e:
        return False
    
def split_pos(row):
    value = row['Pos']
    try:
        name = row["Name"]
        value_split = value.split(sep="/")
        if len(value_split) == 1:
            return value_split[0]
        elif (value_split[0] == ""):
            return value_split[1]
        else:
            return value_split[0].replace("*","")
    except Exception as e:
        print(e)
        return "U"
    
def find_draft_rank(row):
    value = row['Draft/Signing']
    if type(value) == str:
        full_matches = re.search(r'\b\d+(st|nd|rd|th)\b pick', value)
        if full_matches:
            return re.search(r'\d+', full_matches[0])[0]
        else:
            return None
    else:
        return None

def find_draft_round(row):
    value = row['Draft/Signing']
    if type(value) == str:
        full_matches = re.search(r'\b\d+(st|nd|rd|th)\b round', value)
        if full_matches:
            return re.search(r'\d+', full_matches[0])[0]
        else:
            return None
    else:
        return None
    
def find_sign_date(row):
    global pattern
    value = row['Draft/Signing']
    if type(value) == str:
        full_matches = re.findall(r'\b\d{4}\b amateur', value)
        if full_matches:
            year_pattern = r'\b\d{4}\b'
            matches = re.findall(year_pattern, full_matches[0])
            date_obj = datetime.strptime(f"January 1 {matches[0]}", "%B %d %Y")
        else:
            year_pattern = r'\b\d{4}\b'
            matches = re.findall(year_pattern, value)
            date_obj = datetime.strptime(f"January 1 {matches[0]}", "%B %d %Y")
        return date_obj

    else:
        return None

def rework_debut(row):
    date_str = row['Debut']
    date_str=date_str+" "+str(row["data_year"])
    date_obj = None
    try:
        date_obj = datetime.strptime(date_str, "%b %d %Y")
    except:
        date_obj = None
    if date_obj == None:
        try:
            date_obj = datetime.strptime(date_str, "%d-%b %Y")
        except:
            date_obj = None
    if date_obj == None:
        print("WTF")
    return date_obj

def date_diff(row):
    date_1 = row['Debut']
    date_2 = row['sign_date']
    # Total difference
    delta = date_2 - date_1

    # Days difference
    days_diff = delta.days

    #not exact w/ leap years
    years_diff = days_diff / 365
    return years_diff


df = pd.read_csv("total_debut.csv")
df['high_use'] = df['Pos'].str.contains(r'\*')
df['greater_than_10'] = df.apply(greater_than_10, axis=1)
df['drafted'] = df['Draft/Signing'].str.contains(r'Drafted')
df['free_agent'] = df['drafted'].apply(lambda x: not x)
df['bats_right'] = df['B'].str.contains(r'R|B', na=False)
df['bats_left'] = df['B'].str.contains(r'L|B', na=False)
df['throws_right'] = df['T'].str.contains(r'R|B', na=False)
df['throws_left'] = df['T'].str.contains(r'L|B', na=False)
df['positions'] = df.apply(split_pos, axis=1)
df['draft_rank'] = df.apply(find_draft_rank, axis=1)
df['draft_round'] = df.apply(find_draft_round, axis=1)
df['sign_date'] = df.apply(find_sign_date, axis=1)
df['Debut'] = df.apply(rework_debut, axis=1)
df['date_diff'] = df.apply(date_diff, axis=1)

for position in positions_list:
    df[f"pos_{position}"] = df['positions'].str.contains(str(position))
df.to_csv("extra_columns_rookie.csv")