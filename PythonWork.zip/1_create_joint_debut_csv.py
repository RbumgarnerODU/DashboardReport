import pandas as pd
import glob
import os

# Set your folder path
folder_path = 'debut_files'  # <-- change this to your actual path

# Find all CSV files in the folder
csv_files = glob.glob(os.path.join(folder_path, '*.csv'))

# Load and concatenate all CSVs
df_list = []
for file in csv_files:
    df = pd.read_csv(file)
    year = int(file.split(sep="_")[2][:4])
    df["data_year"] = year
    df_list.append(df)
combined_df = pd.concat(df_list, ignore_index=True)
combined_df.to_csv("total_debut.csv")