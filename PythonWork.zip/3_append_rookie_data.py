import pandas as pd

import glob

import os

def check_dups(dataframe, name):
    column_to_check = name

# Check for duplicates
    has_duplicates = dataframe.duplicated(subset=column_to_check).any()

    return has_duplicates

batting_columns = ["Name-additional","HR","RBI","SO","BA","SLG","OPS"]
pitching_columns = ["Name-additional","ERA","WHIP","BF"]
fielding_columns = ['Name-additional',"Inn","PO","E","Fld%","Rdrs"]
# Set your folder path
folder_path = 'rookie_files'  # <-- change this to your actual path
debut_files = 'debut_files'
output_files = 'debut_and_rookie'

# Find all CSV files in the folder
rookie_files = glob.glob(os.path.join(folder_path, '*.csv'))

debut_files = glob.glob(os.path.join(debut_files, '*.csv'))

df_main = pd.read_csv("extra_columns_rookie.csv")
batting = []
fielding = []
pitching = []

for num_year in df_main['data_year'].unique().tolist():
    try:
        year = str(num_year)
        rookie_df_batting = pd.read_csv(folder_path+"\\"+"batting_{}.csv".format(year))
        filtered_batting_df = rookie_df_batting[[col for col in batting_columns if col in rookie_df_batting.columns]]

        rookie_df_pitching = pd.read_csv(folder_path+"\\"+"pitching_{}.csv".format(year))
        filtered_pitching_df = rookie_df_pitching[[col for col in pitching_columns if col in rookie_df_pitching.columns]]

        rookie_df_fielding = pd.read_csv(folder_path+"\\"+"fielding_{}.csv".format(year))
        rookie_df_fielding.rename(columns={'-9999':"Name-additional"}, inplace=True)
        filtered_fielding_df = rookie_df_fielding[[col for col in fielding_columns if col in rookie_df_fielding.columns]]
        # Get the row with the highest 'Score' in each 'Group'
        filtered_fielding_df = filtered_fielding_df.sort_values('Inn', ascending=False).drop_duplicates('Name-additional')
        
        filtered_fielding_df['joined_year'] = year
        filtered_batting_df['joined_year'] = year
        filtered_pitching_df['joined_year'] = year


        bat_dups = check_dups(filtered_batting_df,"Name-additional")
        pitch_dups = check_dups(filtered_pitching_df,"Name-additional")
        field_dups = check_dups(filtered_fielding_df,"Name-additional")

        print(f"dups from {year} in pitch {pitch_dups} bat {bat_dups} field {field_dups}")

        batting.append(filtered_batting_df)
        fielding.append(filtered_fielding_df)
        pitching.append(filtered_pitching_df)
    except Exception as e:
        print(repr(e)+f" with file {year}")

all_pitching = pd.concat(pitching)
all_batting = pd.concat(batting)
all_fielding = pd.concat(fielding)

all_fielding = all_fielding.sort_values('joined_year', ascending=True).drop_duplicates('Name-additional')


bat_dups = check_dups(filtered_batting_df,"Name-additional")
pitch_dups = check_dups(filtered_pitching_df,"Name-additional")
field_dups = check_dups(filtered_fielding_df,"Name-additional")

print(f"dups from all in pitch {pitch_dups} bat {bat_dups} field {field_dups}")

df_main = pd.merge(df_main,all_pitching,on="Name-additional",how="left")

df_main = pd.merge(df_main,all_batting,on="Name-additional",how="left")

df_main = pd.merge(df_main,all_fielding,on="Name-additional", how="left")
df_main.to_csv("final_data.csv")