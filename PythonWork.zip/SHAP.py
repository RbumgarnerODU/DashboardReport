import shap
import pandas as pd
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# 1. Load and split data
df = pd.read_csv("filter_for_shap.csv")  # Replace with your actual file path
df["Tm"] = df["Tm"].astype("category").cat.codes
# 2. Assume last column is target
target_col = df.columns[-1]

X = df.drop(columns=target_col)
X_encoded = pd.get_dummies(X, drop_first=True)
y = df[target_col]

X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

# 2. Train a tree-based model (XGBoost)
model = xgb.XGBRegressor(n_estimators=1000, max_depth=6, learning_rate=0.1)
model.fit(X_train, y_train)

# 3. Create a SHAP TreeExplainer
explainer = shap.Explainer(model)

# 4. Calculate SHAP values for the test set
shap_values = explainer(X_test)

# 5. Visualizations

# a. Summary plot (feature importance)
shap.summary_plot(shap_values, X_test)

# c. Force plot (for a single prediction)
shap.initjs()
sample_idx = 0
shap.force_plot(explainer.expected_value, shap_values.values[sample_idx], X_test.iloc[sample_idx])

# Combine SHAP values and feature values into a single DataFrame
shap_df = pd.DataFrame(shap_values.values, columns=X_test.columns)
shap_df['prediction'] = model.predict(X_test)
shap_df['true_value'] = y_test.values

# Save to CSV
shap_df.to_csv("shap_values_with_predictions.csv", index=False)